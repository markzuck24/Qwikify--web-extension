(function main() {
  console.log('created main function, getting called');
})();

