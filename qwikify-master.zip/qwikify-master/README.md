# qwikify

Qwikify - Hackathon 2019 AFT